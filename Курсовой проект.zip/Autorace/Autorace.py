# ------------------------------------ << БИБЛИОТЕКИ >> ------------------------------------- #
import tkinter as tk
from tkinter import *
from tkinter import ttk
import sqlite3
from DB import *
# ------------------------------------------------------------------------------------------- #


# ------------------------------------ << РАБОТА С БД >> ------------------------------------ #

# ------------------------------------------------------------------------- #

class Points():

    def __init__(self):
        self.db = db   # экземпляр класса DB
        self.variable = []
        self.selected_item = 0
        self.viewRecords()
        #self.funcs()

    # ------------------------ ФУНКЦИИ БД (Пункты) ----------------------- #
    def viewRecords(self):
        ''' Вывод данных '''
        self.db.cur.execute(
            '''SELECT * FROM Points''')
        self.variable.clear()   # очищаем прошлые данные (чтобы не дублировались)
        [self.variable.append(row) for row in self.db.cur.fetchall()]   # записываем новый результат

    # ------------------------- TKINTER (Пункты) ------------------------- #

    def tablePoints(self):
        ''' Создание таблицу с помощью ttk.Treeview() '''
        # Задаем расположение таблицы
        frame = tk.Frame(root, width=100, height=100)
        frame.place(x=10, y=140)

        # Создаем заголовоки для таблицы
        headers = ['ID', 'Код пункта', 'Название']
        self.table = ttk.Treeview(frame, columns=headers, height=15, show='headings')

        self.table.column('ID', width=50, anchor='center') 
        self.table.column('Код пункта', width=300, anchor='center') 
        self.table.column('Название', width=450, anchor='center')

        
        for header in headers:  # заполняем заголовоки
            self.table.heading(header, text=header)
            
        for i in self.variable: # заполняем значения
            self.table.insert('', tk.END, values=i)

        # Создаем скролл для таблицы
        scroll = ttk.Scrollbar(frame, command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.table.pack(expand=tk.YES, fill=tk.BOTH)
 
    def editPoints(self):
        ''' Редактирование таблицы '''
        def closeFunc():
            z.destroy() # закрываем окно

        # Создаем новое окно
        z = Toplevel()
        z.geometry('225x200')
        z.title('Edit')
        z.resizable(False, False)

        # Получаем данные строки по клику
        selected_item = self.table.selection()[0]
        values = self.table.item(selected_item, option='values')

        # Заносим данные строки в переменные
        id = values[0]
        Item_code = values[1]
        Name = values[2]


        # Создаем метки и их расположение
        Item_code_label = Label(z, text='Код пункта').place(x=10, y=10, width=90, height=30)
        Name_label = Label(z, text='Название').place(x=10, y=60, width=70, height=30)


        # Переменные для ввода значений
        Item_code_1 = StringVar()
        Name_2 = StringVar()


        # Строки для ввода значений
        Item_code_entry = Entry(z, width=50, textvariable=Item_code_1)
        Name_entry = Entry(z, width=50, textvariable=Name_2)


        # Записываем значения из строк ввода
        Item_code_entry.insert(0, str(Item_code))
        Name_entry.insert(0, str(Name))


        # Задаем расположение строк ввода
        Item_code_entry.place(x=100, y=10, width=110, height=30)
        Name_entry.place(x=100, y=60, width=110, height=30)


        # Создаем кнопку "Редактировать"
        edit_button = Button(z, text='Редактировать', command=lambda:
                             (self.db.updateRecord1(Item_code_1.get(), Name_2.get(), id), self.viewRecords(), self.tablePoints()))
        edit_button.place(x=10, y=160, width=100, height=30)

        # Создаем кнопку "Закрыть"
        close_button = Button(z, text='Закрыть', command=closeFunc)
        close_button.place(x=115, y=160, width=100, height=30)


              
    def idDelete(self):
        ''' Удаление строки по id из БД '''
        self.selected_item = self.table.selection()[0]  # получаем строку
        values = self.table.item(self.selected_item, option='values')   # получаем значения строки
        delete_id = values[0]   # получаем id строки
        self.db.deleteRecords1(delete_id)   # удаляем строку по полученному id
        
    def lineDelete(self):
        ''' Удаление выбранной строки из таблицы tkinter '''
        self.table.delete(self.selected_item)   # удаляем полученную строку

# ------------------------------  Грузы  ------------------------------ #
# ----------------------------------------------------------------------- #
 
class Cargo():

    def __init__(self):
        self.db = db   # экземпляр класса DB
        self.variable = []
        self.selected_item = 0
        self.viewRecords()

    # ------------------------- ФУНКЦИИ БД (Грузы) ------------------------ #

    def viewRecords(self):
        ''' Вывод данных '''
        self.db.cur.execute(
            '''SELECT * FROM Cargo''')
        self.variable.clear()   # очищаем прошлые данные (чтобы не дублировались)
        [self.variable.append(row) for row in self.db.cur.fetchall()]   # записываем новый результат

    # -------------------------- TKINTER (Грузы) -------------------------- #

    def tableCargo(self):
        ''' Создание таблицу с помощью ttk.Treeview() '''
        # Задаем расположение таблицы
        frame = tk.Frame(root, width=100, height=100)
        frame.place(x=10, y=140)

        # Создаем заголовоки для таблицы
        headers = ['ID', 'Код груза', 'Название', 'Масса']
        self.table = ttk.Treeview(frame, columns=headers, height=15, show='headings')
        
        self.table.column('ID', width=50, anchor='center')
        self.table.column('Код груза', width=240, anchor='center') 
        self.table.column('Название', width=255, anchor='center')
        self.table.column('Масса', width=255, anchor='center')

        
        for header in headers:  # заполняем заголовоки
            self.table.heading(header, text=header)
            
        for i in self.variable: # заполняем значения
            self.table.insert('', tk.END, values=i)

        # Создаем скролл для таблицы
        scroll = ttk.Scrollbar(frame, command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.table.pack(expand=tk.YES, fill=tk.BOTH)
  
    def editCargo(self):
        ''' Редактирование таблицы '''
        def closeFunc():
            z.destroy() # закрываем окно

        # Создаем новое окно
        z = Toplevel()
        z.geometry('270x200')
        z.title('Edit')
        z.resizable(False, False)

        # Получаем данные строки по клику
        selected_item = self.table.selection()[0]
        values = self.table.item(selected_item, option='values')

        # Заносим данные строки в переменные
        id = values[0]
        Cargo_code = values[1]
        Name = values[2]
        Weight = values[3]


        # Создаем метки и их расположение
        Cargo_code_label = Label(z, text='Код груза').place(x=20, y=10, width=70, height=30)
        Name_label = Label(z, text='Название').place(x=20, y=60, width=70, height=30)
        Weight_label = Label(z, text='Масса').place(x=20, y=100, width=70, height=30)

        # Переменные для ввода значений
        Cargo_code_1 = StringVar()
        Name_2 = StringVar()
        Weight_3 = StringVar()


        # Строки для ввода значений
        Cargo_code_entry = Entry(z, width=50, textvariable=Cargo_code_1)
        Name_entry = Entry(z, width=50, textvariable=Name_2)
        Weight_entry = Entry(z, width=50, textvariable=Weight_3)


        # Записываем значения из строк ввода
        Cargo_code_entry.insert(0, str(Cargo_code))
        Name_entry.insert(0, str(Name))
        Weight_entry.insert(0, str(Weight))


        # Задаем расположение строк ввода
        Cargo_code_entry.place(x=100, y=10, width=120, height=30)
        Name_entry.place(x=100, y=60, width=120, height=30)
        Weight_entry.place(x=100, y=100, width=120, height=30)
        # Создаем кнопку "Редактировать"
        edit_button = Button(z, text='Редактировать', command=lambda:
                             (self.db.updateRecord2(Cargo_code_1.get(), Name_2.get(), Weight_3.get(), id), self.viewRecords(), self.tableCargo()))
        edit_button.place(x=10, y=150, width=100, height=30)

        # Создаем кнопку "Закрыть"
        close_button = Button(z, text='Закрыть', command=closeFunc)
        close_button.place(x=115, y=150, width=100, height=30)
        
    def idDelete(self):
        ''' Удаление строки по id из БД '''
        self.selected_item = self.table.selection()[0]  # получаем строку
        values = self.table.item(self.selected_item, option='values')   # получаем значения строки
        delete_id = values[0]   # получаем id строки
        self.db.deleteRecords2(delete_id)   # удаляем строку по полученному id
        
    def lineDelete(self):
        ''' Удаление выбранной строки из таблицы tkinter '''
        self.table.delete(self.selected_item)   # удаляем полученную строку


# ------------------------------ Автомобили ------------------------------ #
# -------------------------------------------------------------------- #

class Cars():

    def __init__(self):
        self.db = db   # экземпляр класса DB
        self.variable = []
        self.selected_item = 0
        self.viewRecords()

    # -------------------------- ФУНКЦИИ БД (Автомобили) -------------------------- #
    def viewRecords(self):
        ''' Вывод данных '''
        self.db.cur.execute(
            '''SELECT * FROM Cars''')
        self.variable.clear()   # очищаем прошлые данные (чтобы не дублировались)
        [self.variable.append(row) for row in self.db.cur.fetchall()]   # записываем новый результат

    # ---------------------------- TKINTER (Автомобили) --------------------------- #

    def tableCars(self):
        ''' Создание таблицу с помощью ttk.Treeview() '''
        # Задаем расположение таблицы
        frame = tk.Frame(root, width=100, height=100)
        frame.place(x=10, y=140)

        # Создаем заголовоки для таблицы
        headers = ['ID', 'Код автомобиля', 'Марка','Гос номер', 'Грузоподъемность']
        self.table = ttk.Treeview(frame, columns=headers, height=15, show='headings')
        
        self.table.column('ID', width=50, anchor='center')
        self.table.column('Код автомобиля', width=200, anchor='center') 
        self.table.column('Марка', width=200, anchor='center')
        self.table.column('Гос номер', width=200, anchor='center')
        self.table.column('Грузоподъемность', width=150, anchor='center')

        
        for header in headers:  # заполняем заголовоки
            self.table.heading(header, text=header)
            
        for i in self.variable: # заполняем значения
            self.table.insert('', tk.END, values=i)

        # Создаем скролл для таблицы
        scroll = ttk.Scrollbar(frame, command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.table.pack(expand=tk.YES, fill=tk.BOTH)
 
    def editCars(self):
        ''' Редактирование таблицы '''
        def closeFunc():
            z.destroy() # закрываем окно
            

        # Создаем новое окно
        z = Toplevel()
        z.geometry('290x260')
        z.title('Edit')
        z.resizable(False, False)

        # Получаем данные строки по клику
        selected_item = self.table.selection()[0]
        values = self.table.item(selected_item, option='values')

        # Заносим данные строки в переменные
        id = values[0]
        Car_code = values[1]
        Make = values[2]
        State_number = values[3]
        Load_capacity = values[4]


        # Создаем метки и их расположение
        Car_code_label = Label(z, text='Код автомобиля').place(x=20, y=10, width=100, height=30)
        Make_label = Label(z, text='Марка').place(x=20, y=60, width=100, height=30)
        State_number_label = Label(z, text='Гос номер').place(x=20, y=100, width=100, height=30)
        Load_capacity_label = Label(z, text='Грузоподъемность').place(x=20, y=140, width=100, height=30)


        # Переменные для ввода значений
        Car_code_1 = StringVar()
        Make_2 = StringVar()
        State_number_3 = StringVar()
        Load_capacity_4 = StringVar()



        # Строки для ввода значений
        Car_code_entry = Entry(z, width=50, textvariable=Car_code_1)
        Make_entry = Entry(z, width=50, textvariable=Make_2)
        State_number_entry = Entry(z, width=50, textvariable=State_number_3)
        Load_capacity_entry = Entry(z, width=50, textvariable=Load_capacity_4)


        # Записываем значения из строк ввода
        Car_code_entry.insert(0, str(Car_code))
        Make_entry.insert(0, str(Make))
        State_number_entry.insert(0, str(State_number))
        Load_capacity_entry.insert(0, str(Load_capacity))


        # Задаем расположение строк ввода
        Car_code_entry.place(x=140, y=10, width=120, height=30)
        Make_entry.place(x=140, y=60, width=120, height=30)
        State_number_entry.place(x=140, y=100, width=120, height=30)
        Load_capacity_entry.place(x=140, y=140, width=120, height=30)


        # Создаем кнопку "Редактировать"
        edit_button = Button(z, text='Редактировать', command=lambda:
                             (self.db.updateRecord3(Car_code_1.get(), Make_2.get(), State_number_3.get(), Load_capacity_4.get(), id), self.viewRecords(), self.tableCars()))
        edit_button.place(x=10, y=220, width=100, height=30)

        # Создаем кнопку "Закрыть"
        close_button = Button(z, text='Закрыть', command=closeFunc)
        close_button.place(x=115, y=220, width=100, height=30)
        
    def idDelete(self):
        ''' Удаление строки по id из БД '''
        self.selected_item = self.table.selection()[0]  # получаем строку
        values = self.table.item(self.selected_item, option='values')   # получаем значения строки
        delete_id = values[0]   # получаем id строки
        self.db.deleteRecords3(delete_id)   # удаляем строку по полученному id
        
    def lineDelete(self):
        ''' Удаление выбранной строки из таблицы tkinter '''
        self.table.delete(self.selected_item)   # удаляем полученную строку

# ------------------------------ Водители ------------------------------ #
# -------------------------------------------------------------------- #

class Driver():

    def __init__(self):
        self.db = db   # экземпляр класса DB
        self.variable = []
        self.selected_item = 0
        self.viewRecords()

    # -------------------------- ФУНКЦИИ БД (Водители) -------------------------- #
    def viewRecords(self):
        ''' Вывод данных '''
        self.db.cur.execute(
            '''SELECT * FROM Driver''')
        self.variable.clear()   # очищаем прошлые данные (чтобы не дублировались)
        [self.variable.append(row) for row in self.db.cur.fetchall()]   # записываем новый результат

    # ---------------------------- TKINTER (Водители) --------------------------- #

    def tableDriver(self):
        ''' Создание таблицу с помощью ttk.Treeview() '''
        # Задаем расположение таблицы
        frame = tk.Frame(root, width=100, height=100)
        frame.place(x=10, y=140)

        # Создаем заголовоки для таблицы
        headers = ['ID', 'Код водителя', 'ФИО','Tелефон']
        self.table = ttk.Treeview(frame, columns=headers, height=15, show='headings')
        
        self.table.column('ID', width=50, anchor='center')
        self.table.column('Код водителя', width=250, anchor='center') 
        self.table.column('ФИО', width=250, anchor='center')
        self.table.column('Tелефон', width=250, anchor='center')

        
        for header in headers:  # заполняем заголовоки
            self.table.heading(header, text=header)
            
        for i in self.variable: # заполняем значения
            self.table.insert('', tk.END, values=i)

        # Создаем скролл для таблицы
        scroll = ttk.Scrollbar(frame, command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.table.pack(expand=tk.YES, fill=tk.BOTH)
 
    def editDriver(self):
        ''' Редактирование таблицы '''
        def closeFunc():
            z.destroy() # закрываем окно
            

        # Создаем новое окно
        z = Toplevel()
        z.geometry('260x260')
        z.title('Edit')
        z.resizable(False, False)

        # Получаем данные строки по клику
        selected_item = self.table.selection()[0]
        values = self.table.item(selected_item, option='values')

        # Заносим данные строки в переменные
        id = values[0]
        Drivers_code = values[1]
        Full_name = values[2]
        Phone_number = values[3]


        # Создаем метки и их расположение
        Drivers_code_label = Label(z, text='Код водителя').place(x=20, y=10, width=70, height=30)
        Full_name_label = Label(z, text='ФИО').place(x=20, y=60, width=70, height=30)
        Phone_number_label = Label(z, text='Tелефон').place(x=20, y=100, width=70, height=30)


        # Переменные для ввода значений
        Drivers_code_1 = StringVar()
        Full_name_2 = StringVar()
        Phone_number_3 = StringVar()


        # Строки для ввода значений
        Drivers_code_entry = Entry(z, width=50, textvariable=Drivers_code_1)
        Full_name_entry = Entry(z, width=50, textvariable=Full_name_2)
        Phone_number_entry = Entry(z, width=50, textvariable=Phone_number_3)


        # Записываем значения из строк ввода
        Drivers_code_entry.insert(0, str(Drivers_code))
        Full_name_entry.insert(0, str(Full_name))
        Phone_number_entry.insert(0, str(Phone_number))


        # Задаем расположение строк ввода
        Drivers_code_entry.place(x=100, y=10, width=120, height=30)
        Full_name_entry.place(x=100, y=60, width=120, height=30)
        Phone_number_entry.place(x=100, y=100, width=120, height=30)


        # Создаем кнопку "Редактировать"
        edit_button = Button(z, text='Редактировать', command=lambda:
                             (self.db.updateRecord4(Drivers_code_1.get(), Full_name_2.get(), Phone_number_3.get(), id), self.viewRecords(), self.tableDriver()))
        edit_button.place(x=10, y=220, width=100, height=30)

        # Создаем кнопку "Закрыть"
        close_button = Button(z, text='Закрыть', command=closeFunc)
        close_button.place(x=115, y=220, width=100, height=30)
        
    def idDelete(self):
        ''' Удаление строки по id из БД '''
        self.selected_item = self.table.selection()[0]  # получаем строку
        values = self.table.item(self.selected_item, option='values')   # получаем значения строки
        delete_id = values[0]   # получаем id строки
        self.db.deleteRecords4(delete_id)   # удаляем строку по полученному id
        
    def lineDelete(self):
        ''' Удаление выбранной строки из таблицы tkinter '''
        self.table.delete(self.selected_item)   # удаляем полученную строку
        

# ------------------------------ Рейсы ------------------------------ #
# -------------------------------------------------------------------- #

class Flights():

    def __init__(self):
        self.db = db   # экземпляр класса DB
        self.variable = []
        self.selected_item = 0
        self.viewRecords()

    # -------------------------- ФУНКЦИИ БД (Рейсы) -------------------------- #
    def viewRecords(self):
        ''' Вывод данных '''
        self.db.cur.execute(
            '''SELECT * FROM Flights''')
        self.variable.clear()   # очищаем прошлые данные (чтобы не дублировались)
        [self.variable.append(row) for row in self.db.cur.fetchall()]   # записываем новый результат

    # ---------------------------- TKINTER (Рейсы) --------------------------- #

    def tableFlights(self):
        ''' Создание таблицу с помощью ttk.Treeview() '''
        # Задаем расположение таблицы
        frame = tk.Frame(root, width=100, height=100)
        frame.place(x=10, y=140)

        # Создаем заголовоки для таблицы
        headers = ['ID', 'Код рейса', 'Код водителя','Код автомобиля','Код пункта','Код груза','Время выезда','Время в пути']
        self.table = ttk.Treeview(frame, columns=headers, height=15, show='headings')
        
        self.table.column('ID', width=50, anchor='center')
        self.table.column('Код рейса', width=100, anchor='center') 
        self.table.column('Код водителя', width=100, anchor='center')
        self.table.column('Код автомобиля', width=100, anchor='center')
        self.table.column('Код пункта', width=100, anchor='center')
        self.table.column('Код груза', width=100, anchor='center')
        self.table.column('Время выезда', width=125, anchor='center')
        self.table.column('Время в пути', width=125, anchor='center')

        
        for header in headers:  # заполняем заголовоки
            self.table.heading(header, text=header)
            
        for i in self.variable: # заполняем значения
            self.table.insert('', tk.END, values=i)

        # Создаем скролл для таблицы
        scroll = ttk.Scrollbar(frame, command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.table.pack(expand=tk.YES, fill=tk.BOTH)
 
    def editFlights(self):
        ''' Редактирование таблицы '''
        def closeFunc():
            z.destroy() # закрываем окно
            

        # Создаем новое окно
        z = Toplevel()
        z.geometry('260x350')
        z.title('Edit')
        z.resizable(False, False)

        # Получаем данные строки по клику
        selected_item = self.table.selection()[0]
        values = self.table.item(selected_item, option='values')

        # Заносим данные строки в переменные
        id = values[0]
        Flight_Code = values[1]
        Driver_Code = values[2]
        Car_Code = values[3]
        Destination_Code = values[4]
        Cargo_Code = values[5]
        Departure_Time = values[6]
        Travel_Time = values[7]


        # Создаем метки и их расположение
        Flight_Code_label = Label(z, text='Код рейса').place(x=20, y=10, width=70, height=30)
        Driver_Code_label = Label(z, text='Код водителя').place(x=20, y=60, width=75, height=30)
        Car_Code_label = Label(z, text='Код автомобиля').place(x=20, y=100, width=90, height=30)
        Destination_Code_label = Label(z, text='Код пункта').place(x=20, y=140, width=70, height=30)
        Cargo_Code_label = Label(z, text='Код груза').place(x=20, y=180, width=70, height=30)
        Departure_Time_label = Label(z, text='Время выезда').place(x=20, y=220, width=90, height=30)
        Travel_Time_label = Label(z, text='Время в пути').place(x=20, y=260, width=70, height=30)


        # Переменные для ввода значений
        Flight_Code_1 = StringVar()
        Driver_Code_2 = StringVar()
        Car_Code_3 = StringVar()
        Destination_Code_4 = StringVar()
        Cargo_Code_5 = StringVar()
        Departure_Time_6 = StringVar()
        Travel_Time_7 = StringVar()


        # Строки для ввода значений
        Flight_Code_entry = Entry(z, width=50, textvariable=Flight_Code_1)
        Driver_Code_entry = Entry(z, width=50, textvariable=Driver_Code_2)
        Car_Code_entry = Entry(z, width=50, textvariable=Car_Code_3)
        Destination_Code_entry = Entry(z, width=50, textvariable=Destination_Code_4)
        Cargo_Code_entry = Entry(z, width=50, textvariable=Cargo_Code_5)
        Departure_Time_entry = Entry(z, width=50, textvariable=Departure_Time_6)
        Travel_Time_entry = Entry(z, width=50, textvariable=Travel_Time_7)


        # Записываем значения из строк ввода
        Flight_Code_entry.insert(0, str(Flight_Code))
        Driver_Code_entry.insert(0, str(Driver_Code))
        Car_Code_entry.insert(0, str(Car_Code))
        Destination_Code_entry.insert(0, str(Destination_Code))
        Cargo_Code_entry.insert(0, str(Cargo_Code))
        Departure_Time_entry.insert(0, str(Departure_Time))
        Travel_Time_entry.insert(0, str(Travel_Time))


        # Задаем расположение строк ввода
        Flight_Code_entry.place(x=120, y=10, width=120, height=30)
        Driver_Code_entry.place(x=120, y=60, width=120, height=30)
        Car_Code_entry.place(x=120, y=100, width=120, height=30)
        Destination_Code_entry.place(x=120, y=140, width=120, height=30)
        Cargo_Code_entry.place(x=120, y=180, width=120, height=30)
        Departure_Time_entry.place(x=120, y=220, width=120, height=30)
        Travel_Time_entry.place(x=120, y=260, width=120, height=30)


        # Создаем кнопку "Редактировать"
        edit_button = Button(z, text='Редактировать', command=lambda:
                             (self.db.updateRecord5(Flight_Code_1.get(), Driver_Code_2.get(), Car_Code_3.get(), Destination_Code_4.get(), Cargo_Code_5.get(), Departure_Time_6.get(), Travel_Time_7.get(), id), self.viewRecords(), self.tableFlights()))
        edit_button.place(x=10, y=300, width=100, height=30)

        # Создаем кнопку "Закрыть"
        close_button = Button(z, text='Закрыть', command=closeFunc)
        close_button.place(x=115, y=300, width=100, height=30)
        
    def idDelete(self):
        ''' Удаление строки по id из БД '''
        self.selected_item = self.table.selection()[0]  # получаем строку
        values = self.table.item(self.selected_item, option='values')   # получаем значения строки
        delete_id = values[0]   # получаем id строки
        self.db.deleteRecords5(delete_id)   # удаляем строку по полученному id
        
    def lineDelete(self):
        ''' Удаление выбранной строки из таблицы tkinter '''
        self.table.delete(self.selected_item)   # удаляем полученную строку


# ------------------------------------- << TKINTER >> --------------------------------------- #



# ----------------------------- Points.tk ---------------------------- #
# ------------------------------------------------------------------------- #

class tkPoints():

    def __init__(self):
        self.sale = sale   # экземпляр класса Points()
        self.db = db
    def PointsButton(self):
        ''' Кнопка для открытия таблицы и её функций '''
        def unionFunc():
            ''' Компонует все кнопки функции выше '''
            def addWindow():
                ''' Создание нового окна для кнопки <Добавить> '''
                def closeFunc():
                    s.destroy() # закрываем окно

                # Создаем новое окно
                s = Toplevel()
                s.geometry('250x200')
                s.title('Add')
                s.resizable(False, False)

                Item_code_label = Label(s, text='Код пункта').place(x=10, y=10, width=85, height=30)
                Name_label = Label(s, text='Название').place(x=10, y=60, width=80, height=30)

                
                name_1 = StringVar()
                name_2 = StringVar()


                Item_code_entry = Entry(s, width=50, textvariable=name_1).place(x=130, y=10, width=100, height=30)
                Name_entry = Entry(s, width=50, textvariable=name_2).place(x=130, y=60, width=100, height=30)

                
                add_button = Button(s, text='Добавить', command=lambda: 
                                    (self.db.records1(name_1.get(), name_2.get()), self.sale.viewRecords(), self.sale.tablePoints()))
                add_button.place(x=10, y=160, width=115, height=30)

                close_button = Button(s, text='Закрыть', command=closeFunc)
                close_button.place(x=130, y=160, width=80, height=30)

            self.add_image = tk.PhotoImage(file='pictures/add.png')
            Points_add_button = Button(root, text='Добавить', image=self.add_image, compound='top', command=addWindow)
            Points_add_button.place(x=10, y=50, width=100, height=80)

            self.edit_image = tk.PhotoImage(file='pictures/edit.png')
            Points_edit_button = Button(root, text='Редактировать', image=self.edit_image, compound='top', command=lambda:
                                             self.sale.editPoints())
            Points_edit_button.place(x=120, y=50, width=100, height=80)
            
            self.delete_image = tk.PhotoImage(file='pictures/delete.png')    
            Points_edit_button = Button(root, text='Удалить', image=self.delete_image, compound='top', command=lambda:
                                             (self.sale.idDelete(), self.sale.lineDelete()))
            Points_edit_button.place(x=230, y=50, width=100, height=80)

            
        Points_button = Button(root, text='Points', command=lambda:
                                    (unionFunc(), self.sale.viewRecords(), self.sale.tablePoints()))
        Points_button.place(x=10, y=10, width=100, height=30)

# ------------------------------ Cargo.tk ----------------------------- #
# ------------------------------------------------------------------------- #

class tkCargo():

    def __init__(self):
        self.cust = cust   # экземпляр класса Cargo()
        self.db = db
    def CargoButton(self):
        ''' Кнопка для открытия таблицы и её функций '''
        def unionFunc():
            ''' Компонует все кнопки функции выше '''
            def addWindow():
                ''' Создание нового окна для кнопки <Добавить> '''
                def closeFunc():
                    s.destroy() # закрываем окно

                # Создаем новое окно
                s = Toplevel()
                s.geometry('260x200')
                s.title('Add')
                s.resizable(False, False)

                Cargo_code_label = Label(s, text='Код груза').place(x=20, y=10, width=70, height=30)
                Name_label = Label(s, text='Название').place(x=20, y=60, width=70, height=30)
                Weight_label = Label(s, text='Масса').place(x=20, y=100, width=70, height=30)

                
                name_1 = StringVar()
                name_2 = StringVar()
                name_3 = StringVar()


                Cargo_code_entry = Entry(s, width=50, textvariable=name_1).place(x=130, y=10, width=120, height=30)
                Name_entry = Entry(s, width=50, textvariable=name_2).place(x=130, y=60, width=120, height=30)
                Weight_entry = Entry(s, width=50, textvariable=name_3).place(x=130, y=100, width=120, height=30)

                add_button = Button(s, text='Добавить', command=lambda: 
                                    (self.db.records2(name_1.get(), name_2.get(), name_3.get()), self.cust.viewRecords(), self.cust.tableCargo()))
                add_button.place(x=10, y=160, width=115, height=30)

                close_button = Button(s, text='Закрыть', command=closeFunc)
                close_button.place(x=130, y=160, width=80, height=30)

            self.add_image = tk.PhotoImage(file='pictures/add.png')
            Cargo_add_button = Button(root, text='Добавить', image=self.add_image, compound='top', command=addWindow)
            Cargo_add_button.place(x=10, y=50, width=100, height=80)

            self.edit_image = tk.PhotoImage(file='pictures/edit.png')
            Cargo_edit_button = Button(root, text='Редактировать', image=self.edit_image, compound='top', command=lambda:
                                             self.cust.editCargo())
            Cargo_edit_button.place(x=120, y=50, width=100, height=80)
            
            self.delete_image = tk.PhotoImage(file='pictures/delete.png')    
            Cargo_edit_button = Button(root, text='Удалить', image=self.delete_image, compound='top', command=lambda:
                                             (self.cust.idDelete(), self.cust.lineDelete()))
            Cargo_edit_button.place(x=230, y=50, width=100, height=80)

               
        Cargo_button = Button(root, text='Cargo', command=lambda:
                                  (unionFunc(), self.cust.viewRecords(), self.cust.tableCargo()))
        Cargo_button.place(x=120, y=10, width=100, height=30)



# ------------------------------- Cars.tk ------------------------------- #
# ------------------------------------------------------------------------- #

class tkCars():

    def __init__(self):
        self.orde = orde   # экземпляр класса Cars()
        self.db = db
    def CarsButton(self):
        ''' Кнопка для открытия таблицы и её функций '''
        def unionFunc():
            ''' Компонует все кнопки функции выше '''
            def addWindow():
                ''' Создание нового окна для кнопки <Добавить> '''
                def closeFunc():
                    s.destroy() # закрываем окно



                # Создаем новое окно
                s = Toplevel()
                s.geometry('280x270')
                s.title('Add')
                s.resizable(False, False)


                Car_code_label = Label(s, text='Код автомобиля').place(x=20, y=10, width=100, height=30)
                Make_label = Label(s, text='Марка').place(x=20, y=60, width=70, height=30)
                State_number_label = Label(s, text='Гос номер').place(x=20, y=100, width=70, height=30)
                Load_capacity_number_label = Label(s, text='Грузоподъемность').place(x=22, y=140, width=105, height=30)

                
                name_1 = StringVar()
                name_2 = StringVar()
                name_3 = StringVar()
                name_4 = StringVar()


                Car_code_entry = Entry(s, width=50, textvariable=name_1).place(x=130, y=10, width=120, height=30)
                Make_entry = Entry(s, width=50, textvariable=name_2).place(x=130, y=60, width=120, height=30)
                State_number_entry = Entry(s, width=50, textvariable=name_3).place(x=130, y=100, width=120, height=30)
                Load_capacity_entry = Entry(s, width=50, textvariable=name_4).place(x=130, y=140, width=120, height=30)

                
                add_button = Button(s, text='Добавить', command=lambda:
                                    (self.db.records3(name_1.get(), name_2.get(), name_3.get(), name_4.get()), self.orde.viewRecords(), self.orde.tableCars()))
                add_button.place(x=10, y=230, width=100, height=30)

                close_button = Button(s, text='Закрыть', command=closeFunc)
                close_button.place(x=115, y=230, width=100, height=30)

            self.add_image = tk.PhotoImage(file='pictures/add.png')
            Spec_Sections_add_button = Button(root, text='Добавить', image=self.add_image, compound='top', command=addWindow)
            Spec_Sections_add_button.place(x=10, y=50, width=100, height=80)

            self.edit_image = tk.PhotoImage(file='pictures/edit.png')
            Spec_Sections_edit_button = Button(root, text='Редактировать', image=self.edit_image, compound='top', command=lambda:
                                             self.orde.editCars())
            Spec_Sections_edit_button.place(x=120, y=50, width=100, height=80)
            
            self.delete_image = tk.PhotoImage(file='pictures/delete.png')    
            Spec_Sections_edit_button = Button(root, text='Удалить', image=self.delete_image, compound='top', command=lambda:
                                             (self.orde.idDelete(), self.orde.lineDelete()))
            Spec_Sections_edit_button.place(x=230, y=50, width=100, height=80)

    
        Cars_button = Button(root, text='Cars', command=lambda:
                               (unionFunc(), self.orde.viewRecords(), self.orde.tableCars()))
        Cars_button.place(x=230, y=10, width=100, height=30)

# ------------------------------- Driver.tk ------------------------------- #
# ------------------------------------------------------------------------- #

class tkDriver():

    def __init__(self):
        self.jas = jas   # экземпляр класса Driver()
        self.db = db
    def DriverButton(self):
        ''' Кнопка для открытия таблицы и её функций '''
        def unionFunc():
            ''' Компонует все кнопки функции выше '''
            def addWindow():
                ''' Создание нового окна для кнопки <Добавить> '''
                def closeFunc():
                    s.destroy() # закрываем окно



                # Создаем новое окно
                s = Toplevel()
                s.geometry('280x270')
                s.title('Add')
                s.resizable(False, False)


                Drivers_code_label = Label(s, text='Код водителя').place(x=20, y=10, width=80, height=30)
                Full_name_label = Label(s, text='ФИО').place(x=20, y=60, width=70, height=30)
                Phone_number_label = Label(s, text='Tелефон').place(x=20, y=100, width=70, height=30)

                
                name_1 = StringVar()
                name_2 = StringVar()
                name_3 = StringVar()


                Drivers_code_entry = Entry(s, width=50, textvariable=name_1).place(x=130, y=10, width=120, height=30)
                Full_name_entry = Entry(s, width=50, textvariable=name_2).place(x=130, y=60, width=120, height=30)
                Phone_number_entry = Entry(s, width=50, textvariable=name_3).place(x=130, y=100, width=120, height=30)

                
                add_button = Button(s, text='Добавить', command=lambda:
                                    (self.db.records4(name_1.get(), name_2.get(), name_3.get()), self.jas.viewRecords(), self.jas.tableDriver()))
                add_button.place(x=10, y=230, width=100, height=30)

                close_button = Button(s, text='Закрыть', command=closeFunc)
                close_button.place(x=115, y=230, width=100, height=30)

            self.add_image = tk.PhotoImage(file='pictures/add.png')
            Spec_Sections_add_button = Button(root, text='Добавить', image=self.add_image, compound='top', command=addWindow)
            Spec_Sections_add_button.place(x=10, y=50, width=100, height=80)

            self.edit_image = tk.PhotoImage(file='pictures/edit.png')
            Spec_Sections_edit_button = Button(root, text='Редактировать', image=self.edit_image, compound='top', command=lambda:
                                             self.jas.editDriver())
            Spec_Sections_edit_button.place(x=120, y=50, width=100, height=80)
            
            self.delete_image = tk.PhotoImage(file='pictures/delete.png')    
            Spec_Sections_edit_button = Button(root, text='Удалить', image=self.delete_image, compound='top', command=lambda:
                                             (self.jas.idDelete(), self.jas.lineDelete()))
            Spec_Sections_edit_button.place(x=230, y=50, width=100, height=80)


            
        Driver_button = Button(root, text='Driver', command=lambda:
                               (unionFunc(), self.jas.viewRecords(), self.jas.tableDriver()))
        Driver_button.place(x=340, y=10, width=100, height=30)

# ------------------------------- Flights.tk ------------------------------- #
# ------------------------------------------------------------------------- #

class tkFlights():

    def __init__(self):
        self.fas = fas   # экземпляр класса Flights()
        self.db = db
    def FlightsButton(self):
        ''' Кнопка для открытия таблицы и её функций '''
        def unionFunc():
            ''' Компонует все кнопки функции выше '''
            def addWindow():
                ''' Создание нового окна для кнопки <Добавить> '''
                def closeFunc():
                    s.destroy() # закрываем окно



                # Создаем новое окно
                s = Toplevel()
                s.geometry('280x350')
                s.title('Add')
                s.resizable(False, False)


                Flight_Code_label = Label(s, text='Код рейса').place(x=20, y=10, width=70, height=30)
                Driver_Code_label = Label(s, text='Код водителя').place(x=20, y=60, width=80, height=30)
                Car_Code_label = Label(s, text='Код автомобиля').place(x=20, y=100, width=90, height=30)
                Destination_Code_label = Label(s, text='Код пункта').place(x=20, y=140, width=70, height=30)
                Cargo_Code_label = Label(s, text='Код груза').place(x=20, y=180, width=70, height=30)
                Departure_Time_label = Label(s, text='Время выезда').place(x=20, y=220, width=90, height=30)
                Travel_Time_label = Label(s, text='Время в пути').place(x=20, y=260, width=70, height=30)

                
                name_1 = StringVar()
                name_2 = StringVar()
                name_3 = StringVar()
                name_4 = StringVar()
                name_5 = StringVar()
                name_6 = StringVar()
                name_7 = StringVar()


                Flight_Code_entry = Entry(s, width=50, textvariable=name_1).place(x=130, y=10, width=120, height=30)
                Driver_Code_entry = Entry(s, width=50, textvariable=name_2).place(x=130, y=60, width=120, height=30)
                Car_Code_entry = Entry(s, width=50, textvariable=name_3).place(x=130, y=100, width=120, height=30)
                Destination_Code_entry = Entry(s, width=50, textvariable=name_4).place(x=130, y=140, width=120, height=30)
                Cargo_Code_entry = Entry(s, width=50, textvariable=name_5).place(x=130, y=180, width=120, height=30)
                Departure_Time_entry = Entry(s, width=50, textvariable=name_6).place(x=130, y=220, width=120, height=30)
                Travel_Time_entry = Entry(s, width=50, textvariable=name_7).place(x=130, y=260, width=120, height=30)

                
                add_button = Button(s, text='Добавить', command=lambda:
                                    (self.db.records5(name_1.get(), name_2.get(), name_3.get(), name_4.get(), name_5.get(), name_6.get(), name_7.get()), self.fas.viewRecords(), self.fas.tableFlights()))
                add_button.place(x=10, y=300, width=100, height=30)

                close_button = Button(s, text='Закрыть', command=closeFunc)
                close_button.place(x=115, y=300, width=100, height=30)

            self.add_image = tk.PhotoImage(file='pictures/add.png')
            Spec_Sections_add_button = Button(root, text='Добавить', image=self.add_image, compound='top', command=addWindow)
            Spec_Sections_add_button.place(x=10, y=50, width=100, height=80)

            self.edit_image = tk.PhotoImage(file='pictures/edit.png')
            Spec_Sections_edit_button = Button(root, text='Редактировать', image=self.edit_image, compound='top', command=lambda:
                                             self.fas.editFlights())
            Spec_Sections_edit_button.place(x=120, y=50, width=100, height=80)
            
            self.delete_image = tk.PhotoImage(file='pictures/delete.png')    
            Spec_Sections_edit_button = Button(root, text='Удалить', image=self.delete_image, compound='top', command=lambda:
                                             (self.fas.idDelete(), self.fas.lineDelete()))
            Spec_Sections_edit_button.place(x=230, y=50, width=100, height=80)


            
        Flights_button = Button(root, text='Flights', command=lambda:
                               (unionFunc(), self.fas.viewRecords(), self.fas.tableFlights()))
        Flights_button.place(x=450, y=10, width=100, height=30)

                

# ------------------------------------------------------------------------------------------- #

if __name__ == "__main__":
    
    db = DB1()

    root = tk.Tk()
    root.geometry('830x485')
    root.title('Диспетчер автоперевозок')
    root.resizable(False, False)

    sale = Points()
    cust = Cargo()
    orde = Cars()
    fas = Flights()
    jas = Driver()

    s = tkPoints()
    c = tkCargo()
    o = tkCars()
    f = tkFlights()
    j = tkDriver()

    s.PointsButton()
    c.CargoButton()
    o.CarsButton()
    f.FlightsButton()
    j.DriverButton()


    root.mainloop()

# ------------------------------------------------------------------------------------------- #
