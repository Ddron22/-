import sqlite3

class DB1:
    
    def __init__(self):
        # Создаем подключение к БД
        self.conn = sqlite3.connect('Road_Transport_Dispatcher.db')
        self.cur = self.conn.cursor()
        self.selected_item = 0

        # Создаем таблицу Points(Пункты)
        self.cur.execute(
            '''CREATE TABLE IF NOT EXISTS Points (ID_1 integer primary key AUTOINCREMENT NULL, 'Код пункта' text, 'Название' text)''')
        
        # Создаем таблицу Cargo(Грузы)
        self.cur.execute(
            '''CREATE TABLE IF NOT EXISTS Cargo (ID_2 integer primary key AUTOINCREMENT NULL, 'Код груза' text, 'Название' text, 'Масса' text )''')
        
        # Создаем таблицу Cars(Автомобили)
        self.cur.execute(
            '''CREATE TABLE IF NOT EXISTS Cars (ID_3 integer primary key AUTOINCREMENT NULL, 'Код автомобиля' text, 'Марка' text, 'Гос номер' text, 'Грузоподъемность' text)''')
        self.conn.commit()

        # Создаем таблицу Driver(Водители)
        self.cur.execute(
            '''CREATE TABLE IF NOT EXISTS Driver (ID_4 integer primary key AUTOINCREMENT NULL, 'Код водителя' text, 'ФИО' text, 'Tелефон' int)''')
        self.conn.commit()

        # Создаем таблицу Flights(Рейсы)
        self.cur.execute(
            '''CREATE TABLE IF NOT EXISTS Flights (ID_5 integer primary key AUTOINCREMENT NULL, 'Код рейса' text, 'Код водителя' text, 'Код автомобиля' text, 'Код пункта' text, 'Код груза' text, 'Время выезда' text, 'Время в пути' text)''')
        self.conn.commit()

    def insertDataPoints(self, Item_code, Name):
        ''' Добавление данных для Assortment '''
        self.cur.execute(
            '''INSERT INTO Points('Код пункта', 'Название') VALUES (?, ?)''', (Item_code, Name))
        self.conn.commit()

    def insertDataCargo(self, Cargo_code, Name, Weight):
        ''' Добавление данных для Shopping_cart '''
        self.cur.execute(
            '''INSERT INTO Cargo('Код груза', 'Название', 'Масса') VALUES (?, ?, ?)''', (Cargo_code, Name, Weight))
        self.conn.commit()

    def insertDataCars(self, Car_code, Make, State_number, Load_capacity):
        ''' Добавление данных для Workers '''
        self.cur.execute(
            '''INSERT INTO Cars('Код автомобиля', 'Марка', 'Гос номер', 'Грузоподъемность') VALUES (?, ?, ?, ?)''', (Car_code, Make, State_number, Load_capacity))
        self.conn.commit()

    def insertDataDriver(self, Drivers_code, Full_name, Phone_number):
        ''' Добавление данных для Workers '''
        self.cur.execute(
            '''INSERT INTO Driver('Код водителя', 'ФИО', 'Tелефон') VALUES (?, ?, ?)''', (Drivers_code, Full_name, Phone_number))
        self.conn.commit()

    def insertDataFlights(self, Flight_Code, Driver_Code, Car_Code, Destination_Code, Cargo_Code, Departure_Time, Travel_Time):
        ''' Добавление данных для Workers '''
        self.cur.execute(
            '''INSERT INTO Flights('Код рейса', 'Код водителя', 'Код автомобиля', 'Код пункта', 'Код груза', 'Время выезда', 'Время в пути') VALUES (?, ?, ?, ?, ?, ?, ?)''', (Flight_Code, Driver_Code, Car_Code, Destination_Code, Cargo_Code, Departure_Time, Travel_Time))
        self.conn.commit()

    #Функции DB (Пункты)
    def records1(self, Item_code, Name):
        ''' Ввод новых данных '''
        self.insertDataPoints(Item_code, Name)

    def updateRecord1(self, Item_code, Name, ID_1):
        ''' Редактирование данных '''
        self.cur.execute(
            '''UPDATE Points SET 'Код пункта'=?, 'Название'=? WHERE ID_1=?''', (Item_code, Name, ID_1))
        self.conn.commit()

    def deleteRecords1(self, ID_1):
        ''' Удаление результата '''
        self.cur.execute(
            '''DELETE FROM Points WHERE ID_1=?''', (ID_1,))
        self.conn.commit()
    

    #Функции DB (Грузы)
    def records2(self, Cargo_code, Name, Weight):
        ''' Ввод новых данных '''
        self.insertDataCargo(Cargo_code, Name, Weight)

    def updateRecord2(self, Cargo_code, Name, Weight, ID_2):
        ''' Редактирование данных '''
        self.cur.execute(
            '''UPDATE Cargo SET 'Код груза'=?, 'Название'=?, 'Масса'=?  WHERE ID_2=?''', (Cargo_code, Name, Weight, ID_2))
        self.conn.commit()

    def deleteRecords2(self, ID_2):
        ''' Удаление результата '''
        self.cur.execute(
            '''DELETE FROM Cargo WHERE ID_2=?''', (ID_2,))
        self.conn.commit()
        
    #Функции DB (Автомобили)
    def records3(self, Car_code, Make, State_number, Load_capacity):
        ''' Ввод новых данных '''
        self.insertDataCars(Car_code, Make, State_number, Load_capacity)

    def updateRecord3(self, Car_code, Make, State_number, Load_capacity, ID_3):
        ''' Редактирование данных '''
        self.cur.execute(
            '''UPDATE Cars SET 'Код автомобиля'=?, 'Марка'=?, 'Гос номер'=?, 'Грузоподъемность'=? WHERE ID_3=?''', (Car_code, Make, State_number, Load_capacity, ID_3))
        self.conn.commit()

    def deleteRecords3(self, ID_3):
        ''' Удаление результата '''
        self.cur.execute(
            '''DELETE FROM Cars WHERE ID_3=?''', (ID_3,))
        self.conn.commit()
        
    #Функции DB (Водители)
    def records4(self, Drivers_code, Full_name, Phone_number):
        ''' Ввод новых данных '''
        self.insertDataDriver(Drivers_code, Full_name, Phone_number)

    def updateRecord4(self, Drivers_code, Full_name, Phone_number, ID_4):
        ''' Редактирование данных '''
        self.cur.execute(
            '''UPDATE Driver SET 'Код водителя'=?, 'ФИО'=?, 'Tелефон'=? WHERE ID_4=?''', (Drivers_code, Full_name, Phone_number, ID_4))
        self.conn.commit()

    def deleteRecords4(self, ID_4):
        ''' Удаление результата '''
        self.cur.execute(
            '''DELETE FROM Driver WHERE ID_4=?''', (ID_4,))
        self.conn.commit()
        
    #Функции DB (Рейсы)
    def records5(self, Flight_Code, Driver_Code, Car_Code, Destination_Code, Cargo_Code, Departure_Time, Travel_Time):
        ''' Ввод новых данных '''
        self.insertDataFlights(Flight_Code, Driver_Code, Car_Code, Destination_Code, Cargo_Code, Departure_Time, Travel_Time)

    def updateRecord5(self, Flight_Code, Driver_Code, Car_Code, Destination_Code, Cargo_Code, Departure_Time, Travel_Time, ID_5):
        ''' Редактирование данных '''
        self.cur.execute(
            '''UPDATE Flights SET 'Код рейса'=?, 'Код водителя'=?, 'Код автомобиля'=?, 'Код пункта'=?, 'Код груза'=?, 'Время выезда'=?, 'Время в пути'=? WHERE ID_5=?''', (Flight_Code, Driver_Code, Car_Code, Destination_Code, Cargo_Code, Departure_Time, Travel_Time, ID_5))
        self.conn.commit()

    def deleteRecords5(self, ID_5):
        ''' Удаление результата '''
        self.cur.execute(
            '''DELETE FROM Flights WHERE ID_5=?''', (ID_5,))
        self.conn.commit()

        
